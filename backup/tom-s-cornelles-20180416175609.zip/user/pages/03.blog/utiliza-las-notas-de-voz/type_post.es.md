---
title: 'Utiliza las Notas de voz'
media_order: voice-control.jpg
color: '#315894'
logoColor: white
date: '05-03-2015 14:59'
taxonomy:
    tag:
        - productividad
---

Hace unos días me sorprendí observando como mi pareja se comunicaba mediante notas de audio con una cliente. Mientras una pasea a sus perros por la mañana en Toledo, graba mensajes y los envía por Whatsapp™. Por otro lado en Barcelona, durante el trayecto en autobús, los escucha y  atiende a las nuevas necesidades.

Sería más rápido y directo una llamada de teléfono, sin embargo no siempre se puede coincidir para una llamada o videoconferencia, lo cual retrasaría el intercambio de ideas. El contacto se refuerza con los habituales mails además de una llamada semanal.

Mediante esta sencilla técnica ambas aprovechan unos espacios que se hubieran perdido en el tiempo.