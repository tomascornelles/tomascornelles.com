---
title: 'Dolce Sitges Blog'
media_order: 'dolce001.png,dolce002.png,dolce003.png'
color: '#941f27'
logoColor: white
published: false
date: '01-04-2018 00:00'
taxonomy:
    type:
        - 'Desarrollo Web'
    tech:
        - WordPress
    client:
        - 'Plan Comunicacion'
        - 'Dolce Sitges'
    year:
        - '2018'
---

