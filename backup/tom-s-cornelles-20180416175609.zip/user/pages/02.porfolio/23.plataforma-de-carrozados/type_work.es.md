---
title: 'Plataforma de carrozados'
media_order: 'pc001.png,pc002.png,pc003.png,pc004.png'
color: '#c3002f'
logoColor: white
published: false
date: '01-04-2017 13:00'
taxonomy:
    type:
        - 'Desarrollo Web'
        - webapp
    tech:
        - CSS
        - JS
    client:
        - 'Plan Comunicacion'
        - Nissan
    year:
        - '2017'
---

