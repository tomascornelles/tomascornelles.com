---
title: 'Dockers Tablet'
media_order: 'dockers001.png,dockers.png'
color: '#eb451b'
logoColor: white
date: '01-06-2017 00:00'
taxonomy:
    type:
        - 'Desarrollo Web'
    tech:
        - CSS
    client:
        - Dockers
    year:
        - '2017'
---

Para una campaña para la marca de ropa **Dockers** se prepararon varias tablets, desde las cuales los clientes de las tiendas podía registrarse para obtener descuentos directos.

El funcionamiento es sencillo y se trató de conseguir una experiencia fluida y agradable para que los clientes entregen sus datos.

![Imagen de la tablet](dockers.png)