---
title: 'Flag Finder'
media_order: 'ff001.png,ff002.png,ff003.png'
color: '#34495e'
logoColor: white
published: false
date: '01-11-2017 00:00'
taxonomy:
    type:
        - 'Desarrollo Web'
    tech:
        - CSS
        - JS
    client:
        - Personal
    year:
        - '2017'
---

