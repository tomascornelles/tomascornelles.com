---
title: 'Calculadora financiera'
media_order: 'nissan001.png,cafi_002.png'
color: '#c3002f'
logoColor: white
published: false
date: '01-06-2016 16:33'
taxonomy:
    tag:
        - ampliar
    type:
        - 'Desarrollo Web'
    tech:
        - JS
    client:
        - 'Plan Comunicacion'
        - Nissan
    year:
        - '2016'
---

La calculadora financiera de **Nissan**, es la aplicación mediante la cual se obtienen las cuotas de financiación de cada vehículo.

Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vero in hic fugiat, repellat ratione id quod vitae sequi maiores explicabo ad labore, mollitia minus ab. Sequi repellendus similique, quibusdam enim.

Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vero in hic fugiat, repellat ratione id quod vitae sequi maiores explicabo ad labore, mollitia minus ab. Sequi repellendus similique, quibusdam enim.

Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vero in hic fugiat, repellat ratione id quod vitae sequi maiores explicabo ad labore, mollitia minus ab. Sequi repellendus similique, quibusdam enim.

![Vistas de la versión mobile y escritorio](cafi_002.png)