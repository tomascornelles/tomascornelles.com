---
title: 'Barcelona Motor Show 2017'
media_order: 'bms_001.png,bms_002.png,bms_003.png,bms_004.png,bms_005.png'
color: '#241b4a'
logoColor: white
published: false
date: '01-05-2017 00:00'
taxonomy:
    type:
        - 'Desarrollo Web'
        - webapp
    tech:
        - CSS
        - JS
    client:
        - 'Plan Comunicacion'
        - Nissan
    year:
        - '2017'
---

Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vero in hic fugiat, repellat ratione id quod vitae sequi maiores explicabo ad labore, mollitia minus ab. Sequi repellendus similique, quibusdam enim.

Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vero in hic fugiat, repellat ratione id quod vitae sequi maiores explicabo ad labore, mollitia minus ab. Sequi repellendus similique, quibusdam enim.

Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vero in hic fugiat, repellat ratione id quod vitae sequi maiores explicabo ad labore, mollitia minus ab. Sequi repellendus similique, quibusdam enim.

![](bms_002.png)
![](bms_003.png)
![](bms_004.png)
![](bms_005.png)