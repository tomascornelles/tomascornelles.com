---
title: 'WebComponets WebCat'
media_order: wc001.png
color: '#f39c12'
logoColor: black
published: false
date: '01-05-2015 00:00'
taxonomy:
    type:
        - Conferencia
    tech:
        - WebComponents
    client:
        - Personal
    year:
        - '2015'
---

Video: [https://mosaic.uoc.edu/2015/06/23/webcat-web-components/](https://mosaic.uoc.edu/2015/06/23/webcat-web-components/)
Presentación: [/webcomponents/Pres-webcat-mayo-16-9.pdf](http://tomascornelles.com/webcomponents/Pres-webcat-mayo-16-9.pdf)
Página: [/webcomponents](http://localhost/tomascornelles.com/webcomponents)