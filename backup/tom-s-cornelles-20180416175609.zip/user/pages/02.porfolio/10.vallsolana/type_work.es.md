---
title: Vallsolana
media_order: 'vallsolana001.png,vallsolana002.png,vallsolana003.png'
color: '#8bc854'
logoColor: white
date: '01-03-2015 00:00'
taxonomy:
    type:
        - 'Desarrollo Web'
    tech:
        - WordPress
    client:
        - Vallsolana
        - Singular
    year:
        - '2015'
---

**Vallsolana** es un edificio de oficinas situado en un Parque de Sant Cugat, el cual cuenta con clientes muy reconocidos a nivel mundial.

El resto de este proyecto fue fundamentalmente el tiempo, ya que por diversos motivos debía terminarse en un plazo de 3 dias. Para ayudar con el desarrollo se optó por emplear **Wordpress** y customizar un tema para que se adaptara al gusto del cliente.

Por suerte no disponia de mucha información ni de blog que gestionar y todo salió al gusto del cliente,

![Vista del inicio en Escritorio](vallsolana002.png)
![Varias vistas en móvil](vallsolana003.png)