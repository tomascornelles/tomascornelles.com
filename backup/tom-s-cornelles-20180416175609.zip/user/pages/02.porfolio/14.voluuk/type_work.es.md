---
title: Voluuk
media_order: 'voluuk.png,voluuk001.png,voluuk002.png,voluuk003.png'
color: '#383838'
logoColor: white
date: '01-09-2016 00:00'
taxonomy:
    type:
        - 'Desarrollo Web'
    tech:
        - WordPress
    client:
        - Voluuk
        - Singular
    year:
        - '2016'
---

**Voluuk** es una nueva marca de Barcelona que idearon un original producto para el invierno. Una bufanda corta, cómoda y con estilo para el hombre moderno.

Su web debería mostrar ese estilo elegenat y clásico a la ve que moderno. Para ello se ajustó un tema de **Wordpress** y se prestó especial atención al detalle.

El resultado fue una web al gusto del cliente y con toda la información de sus productos desde cualquier dispositivo.

![Inicio de la web](voluuk001.png)
![Vistas en mobile](voluuk002.png)
![Detalle del producto](voluuk003.png)